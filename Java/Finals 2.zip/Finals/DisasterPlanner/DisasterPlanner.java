package DisasterPlanner;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

public class DisasterPlanner {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter the name of the text file: ");
            String fileName = scanner.nextLine();

            HashMap<String, HashSet<String>> roadNetwork = new HashMap<>();

            if (readRoadNetworkFromFile(fileName, roadNetwork)) {
                int numCities = roadNetwork.size();
                HashSet<String> supplyLocations = new HashSet<>();

                boolean isPossible = allocateResources(roadNetwork, numCities, supplyLocations);

                if (isPossible) {
                    System.out.println("Resource allocation successful!");
                    System.out.println("Supply locations: " + supplyLocations);
                } else {
                    System.out.println("Resource allocation not possible.");
                }
            } else {
                System.out.println("Error reading road network from the file.");
            }
        }
    }

    private static boolean readRoadNetworkFromFile(String fileName, HashMap<String, HashSet<String>> roadNetwork) {
        try {
            Scanner fileScanner = new Scanner(new File(fileName));
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(":");
                String city = parts[0].trim();
                String[] neighbors = parts[1].split(",");
                HashSet<String> neighborSet = new HashSet<>();
                for (String neighbor : neighbors) {
                    neighborSet.add(neighbor.trim());
                }
                roadNetwork.put(city, neighborSet);
            }
            fileScanner.close();
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static boolean allocateResources(HashMap<String, HashSet<String>> roadNetwork, int numCities, HashSet<String> supplyLocations) {
        // Create a copy of the road network to avoid modifying the original data
        HashMap<String, HashSet<String>> networkCopy = new HashMap<>(roadNetwork);
    
        // Check if all cities have access to supplies or are adjacent to a city with supplies
        if (allCitiesCovered(networkCopy, supplyLocations) || numCities == 0) {
            return true;
        }
    
        // Iterate through each city in the road network
        for (String city : roadNetwork.keySet()) {
            // Check if the city already has supplies or is a neighbor of a city with supplies
            if (!supplyLocations.contains(city) && hasNeighborWithSupplies(city, networkCopy, supplyLocations)) {
                // Add the city to the supply locations
                supplyLocations.add(city);
    
                // Remove the city and its neighbors from the copy of the road network
                networkCopy.remove(city);
                for (HashSet<String> neighbors : networkCopy.values()) {
                    neighbors.remove(city);
                }
    
                // Recursive call to continue allocation
                if (allocateResources(networkCopy, numCities - 1, supplyLocations)) {
                    return true;
                }
    
                // Backtrack: undo the supply allocation
                supplyLocations.remove(city);
            }
        }
    
        // No valid allocation found
        return false;
    }
    
    // Helper method to check if all cities have access to supplies or are adjacent to a city with supplies
    private static boolean allCitiesCovered(HashMap<String, HashSet<String>> roadNetwork, HashSet<String> supplyLocations) {
        for (String city : roadNetwork.keySet()) {
            if (!supplyLocations.contains(city) && !hasNeighborWithSupplies(city, roadNetwork, supplyLocations)) {
                return false;
            }
        }
        return true;
    }
    
    // Helper method to check if a city has a neighbor with supplies
    private static boolean hasNeighborWithSupplies(String city, HashMap<String, HashSet<String>> roadNetwork, HashSet<String> supplyLocations) {
        for (String neighbor : roadNetwork.get(city)) {
            if (supplyLocations.contains(neighbor)) {
                return true;
            }
        }
        return false;
    }

    // private static boolean allocateResources(HashMap<String, HashSet<String>> roadNetwork, int numCities, HashSet<String> supplyLocations) {
    //     // Create a copy of the road network to avoid modifying the original data
    //     HashMap<String, HashSet<String>> networkCopy = new HashMap<>(roadNetwork);
    
    //     // Iterate through each city in the road network
    //     for (String city : roadNetwork.keySet()) {
    //         // Check if the city already has supplies or is a neighbor of a city with supplies
    //         if (!supplyLocations.contains(city) && hasNeighborWithSupplies(city, networkCopy, supplyLocations)) {
    //             // Add the city to the supply locations
    //             supplyLocations.add(city);
    
    //             // Remove the city and its neighbors from the copy of the road network
    //             networkCopy.remove(city);
    //             for (HashSet<String> neighbors : networkCopy.values()) {
    //                 neighbors.remove(city);
    //             }
    
    //             // Reset the iteration to start from the beginning
    //             return allocateResources(networkCopy, numCities, supplyLocations);
    //         }
    //     }
    
    //     // Check if all cities are covered
    //     return supplyLocations.size() == numCities;
    // }
    
    // private static boolean allocateResources(HashMap<String, HashSet<String>> roadNetwork, int numCities, HashSet<String> supplyLocations) {
    //     // Create a copy of the road network to avoid modifying the original data
    //     HashMap<String, HashSet<String>> networkCopy = new HashMap<>(roadNetwork);
    
    //     // Iterate through each city in the road network
    //     for (String city : roadNetwork.keySet()) {
    //         // Check if the city already has supplies or is a neighbor of a city with supplies
    //         if (!supplyLocations.contains(city) && hasNeighborWithSupplies(city, networkCopy, supplyLocations)) {
    //             // Add the city to the supply locations
    //             supplyLocations.add(city);
    
    //             // Remove the city and its neighbors from the copy of the road network
    //             networkCopy.remove(city);
    //             for (HashSet<String> neighbors : networkCopy.values()) {
    //                 neighbors.remove(city);
    //             }
    
    //             // Reset the iteration to start from the beginning
    //             city = roadNetwork.keySet().iterator().next();
    //         }
    //     }
    
    //     // Check if all cities are covered
    //     return supplyLocations.size() == numCities;
    // }
    
    // private static boolean allocateResources(HashMap<String, HashSet<String>> roadNetwork, int numCities, HashSet<String> supplyLocations) {
    //     // Base case: All cities are covered
    //     if (supplyLocations.size() == numCities) {
    //         return true;
    //     }
    
    //     // Iterate through each city in the road network
    //     for (String city : roadNetwork.keySet()) {
    //         // Check if the city already has supplies or is a neighbor of a city with supplies
    //         if (!supplyLocations.contains(city) && hasNeighborWithSupplies(city, roadNetwork, supplyLocations)) {
    //             // Add the city to the supply locations
    //             supplyLocations.add(city);
    
    //             // Recursively try allocating supplies for the remaining cities
    //             if (allocateResources(roadNetwork, numCities, supplyLocations)) {
    //                 return true;  // Allocation successful
    //             }
    
    //             // Backtrack: Remove the city from the supply locations
    //             supplyLocations.remove(city);
    //         }
    //     }
    
    //     // No valid allocation found
    //     return false;
    // }
    
    
    
}

